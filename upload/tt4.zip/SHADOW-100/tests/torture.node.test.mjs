// ShadowPaste 1000X security torture test (V14 Phase 1).
// Generates 1000+ fake secrets across every supported provider family and asserts
// ZERO raw leak through the real detection + virtualization pipeline.
// Run: node --test tests   (Node >=20). Mirrors the in-browser torture run.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as crypto from '../packages/crypto/index.mjs';
import { VaultStore } from '../packages/gateway/index.mjs';
import { detectors, classifyProvider, entropyScan } from '../packages/security/index.mjs';

const rnd = (n, set = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789') =>
  Array.from({ length: n }, () => set[(Math.random() * set.length) | 0]).join('');

const gens = {
  OPENAI: () => 'sk-' + rnd(48), OPENAI_PROJ: () => 'sk-proj-' + rnd(48),
  ANTHROPIC: () => 'sk-ant-api03-' + rnd(40), GEMINI: () => 'AIza' + rnd(35),
  MISTRAL_ALPHA: () => rnd(32, 'abcdefghijklmnopqrstuvwxyz'), MISTRAL_MIX: () => rnd(40),
  GROQ: () => 'gsk_' + rnd(52), HF: () => 'hf_' + rnd(34),
  AWS_ACCESS: () => 'AKIA' + rnd(16, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'),
  AWS_SECRET: () => rnd(40, 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/'),
  GITHUB: () => 'ghp_' + rnd(36), GITHUB_PAT: () => 'github_pat_' + rnd(60, 'abcdefghijklmnopqrstuvwxyz0123456789_'),
  GITLAB: () => 'glpat-' + rnd(20), DOCKER: () => 'dckr_pat_' + rnd(36, 'abcdefghijklmnopqrstuvwxyz0123456789_-'),
  NPM: () => 'npm_' + rnd(36),
  MONGODB: () => 'mongodb+srv://user:' + rnd(12) + '@c.mongodb.net/db',
  POSTGRES: () => 'postgres://u:' + rnd(12) + '@host:5432/db', MYSQL: () => 'mysql://root:' + rnd(12) + '@localhost/db',
  REDIS: () => 'redis://:' + rnd(16) + '@host:6379',
  JWT: () => 'eyJ' + rnd(20) + '.' + rnd(30) + '.' + rnd(43),
  STRIPE: () => 'sk_live_' + rnd(40), SLACK: () => 'xoxb-' + rnd(12, '0123456789') + '-' + rnd(24),
  TELEGRAM: () => rnd(9, '0123456789') + ':AA' + rnd(33)
};

// Node-side reproduction of the browser PROTECT pipeline (inline + matrix + entropy),
// virtualizing into an in-memory encrypted vault.
async function protect(text, vault) {
  const refFor = async (raw) => (await vault.add(raw, { provider: classifyProvider(raw).provider, scope: classifyProvider(raw).scope })).reference;
  // inline assignments: key = "value"
  const inline = /((?:[a-z0-9_]*?(?:api[_-]?key|apikey|secret|token|password|passwd|pwd|access[_-]?key|private[_-]?key))\s*[:=]\s*)(["'`])([^"'`\n]{6,})(["'`])/gi;
  for (const m of [...text.matchAll(inline)]) {
    if (/^[a-f0-9]{32}$|^[a-f0-9]{40}$|^[a-f0-9]{64}$/i.test(m[3])) continue;
    text = text.split(m[0]).join(m[1] + m[2] + (await refFor(m[3])) + m[4]);
  }
  // matrix detectors
  for (const d of detectors) {
    if (!d.virtualize) continue;
    for (const raw of [...new Set(text.match(d.regex()) || [])]) text = text.split(raw).join(await refFor(raw));
  }
  // entropy sweep (matches browser gate: letter required, skip hash shapes)
  for (const hit of entropyScan(text)) {
    const tok = hit.token;
    if (/^[a-f0-9]{32}$|^[a-f0-9]{40}$|^[a-f0-9]{64}$/i.test(tok)) continue;
    if (!/[A-Za-z]/.test(tok)) continue;
    text = text.split(tok).join(await refFor(tok));
  }
  return text;
}

test('1000X — zero raw secret leak across all provider families', async () => {
  const vault = new VaultStore(await crypto.generateAesKey());
  const keys = Object.keys(gens);
  const secrets = [];
  for (let i = 0; i < 1050; i++) { const p = keys[i % keys.length]; secrets.push(gens[p]()); }
  const blob = secrets.map((v, i) => `service_${i}_api_key = "${v}"`).join('\n');
  const out = await protect(blob, vault);
  const leaked = secrets.filter(v => out.includes(v));
  assert.equal(leaked.length, 0, `raw secrets leaked: ${leaked.slice(0, 3).join(', ')}`);
});

test('git SHA / hash shapes are preserved (not over-redacted)', () => {
  const sha = 'a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0';
  assert.equal(entropyScan(`commit = "${sha}"`).some(h => h.token === sha), false);
});
