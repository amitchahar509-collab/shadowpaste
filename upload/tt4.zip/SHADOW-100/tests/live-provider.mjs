// OPT-IN live provider test (Phase 2). Runs a REAL API call through the full
// vault → capability → gateway → adapter path, then asserts the raw key never
// appears in logs, results, audit, or vault metadata.
//
// SAFETY: uses a key you provide via env; use a throwaway/limited key. No key is
// hard-coded. Run:
//   OPENAI_API_KEY=sk-... node tests/live-provider.mjs openai
//   ANTHROPIC_API_KEY=sk-ant-... node tests/live-provider.mjs anthropic
//   GEMINI_API_KEY=AIza... node tests/live-provider.mjs gemini

import * as crypto from '../packages/crypto/index.mjs';
import { CapabilityEngine, newSessionId } from '../packages/capability/index.mjs';
import { Gateway, VaultStore } from '../packages/gateway/index.mjs';
import { classifyProvider } from '../packages/security/index.mjs';

const which = process.argv[2] || 'openai';
const keyEnv = { openai: 'OPENAI_API_KEY', anthropic: 'ANTHROPIC_API_KEY', gemini: 'GEMINI_API_KEY' }[which];
const RAW = process.env[keyEnv];
if (!RAW) { console.error(`Set ${keyEnv} to run the live ${which} test.`); process.exit(2); }

const scopeFor = { openai: 'openai.chat', anthropic: 'anthropic.messages', gemini: 'google.generativelanguage' }[which];

const aesKey = await crypto.generateAesKey();
const hmacKey = await crypto.generateHmacKey();
const vault = new VaultStore(aesKey);
const events = [];
const sessionId = newSessionId();
const gateway = new Gateway({ vault, capabilities: new CapabilityEngine(hmacKey), sessionId, audit: e => events.push(e), fetchImpl: fetch });

const cls = classifyProvider(RAW);
const rec = await vault.add(RAW, { provider: cls.provider, scope: scopeFor });
const res = await gateway.requestSecretUse(rec.reference, scopeFor, { prompt: 'Reply with the single word: pong.' });

// Leak assertions across every surface.
const surfaces = { result: JSON.stringify(res), audit: JSON.stringify(events), meta: JSON.stringify(vault.meta(rec.reference)) };
let leaked = false;
for (const [name, blob] of Object.entries(surfaces)) {
  if (blob.includes(RAW)) { console.error(`LEAK in ${name}`); leaked = true; }
}
console.log(`provider=${cls.provider} ok=${res.ok}`);
console.log('response:', res.ok ? (res.text || '').slice(0, 120) : res.error);
console.log('raw key present in [result/audit/meta]:', leaked);
process.exit(res.ok && !leaked ? 0 : 1);
