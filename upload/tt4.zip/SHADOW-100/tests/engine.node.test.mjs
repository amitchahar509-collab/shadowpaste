// ShadowPaste V12 engine test suite — format preservation, classification,
// inline scanning, PROTECT/TEST modes, export safety, large-project throughput.
// Run: node --test tests

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { virtualizeText, providerLabel, containsAnyRaw, aiPreamble } from '../packages/engine/index.mjs';

// ---------- 1. FORMAT PRESERVATION (source code must not be corrupted) ----------

test('FORMAT: .env — only the value changes, key/newlines/comments preserved', () => {
  const src = [
    '# database config',
    'PORT=8787',
    'OPENAI_API_KEY=sk-proj-ABCDEFGHIJKLMNOP1234567890',
    'DATABASE_URL=mongodb+srv://admin:s3cretPass@cluster0.test.mongodb.net/app',
    '',
    'DEBUG=true'
  ].join('\n');
  const { text, count } = virtualizeText(src);
  assert.ok(count >= 2);
  const lines = text.split('\n');
  assert.equal(lines[0], '# database config');       // comment intact
  assert.equal(lines[1], 'PORT=8787');                // non-secret intact
  assert.ok(lines[2].startsWith('OPENAI_API_KEY='));  // key name intact
  assert.match(lines[2], /OPENAI_API_KEY=\{\{SHADOW_SECRET_OPENAI_[A-Z0-9]{5}\}\}/);
  assert.ok(lines[3].startsWith('DATABASE_URL='));    // key name intact
  assert.equal(lines[4], '');                          // blank line intact
  assert.equal(lines[5], 'DEBUG=true');
  assert.ok(!text.includes('sk-proj-ABCDEFGHIJKLMNOP1234567890'));
  assert.ok(!text.includes('s3cretPass'));
});

test('FORMAT: JSON — structure, indentation and quotes preserved', () => {
  const src = JSON.stringify({ name: 'app', apiKey: 'sk-proj-SECRETVALUE1234567890XY', port: 3000 }, null, 2);
  const { text } = virtualizeText(src);
  // still valid JSON
  const parsed = JSON.parse(text);
  assert.equal(parsed.name, 'app');
  assert.equal(parsed.port, 3000);
  assert.match(parsed.apiKey, /^\{\{SHADOW_SECRET_OPENAI_[A-Z0-9]{5}\}\}$/);
  assert.ok(!text.includes('SECRETVALUE1234567890XY'));
  assert.ok(text.includes('\n  "name": "app"')); // 2-space indent preserved
});

test('FORMAT: YAML — indentation preserved, only secret swapped', () => {
  const src = 'service:\n  name: api\n  token: "ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZ012345"\n  replicas: 3\n';
  const { text } = virtualizeText(src);
  assert.ok(text.includes('service:\n  name: api\n'));
  assert.ok(text.includes('  replicas: 3\n'));
  assert.match(text, /  token: "\{\{SHADOW_SECRET_GITHUB_[A-Z0-9]{5}\}\}"/); // quotes kept
  assert.ok(!text.includes('ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZ012345'));
});

test('FORMAT: source code — indentation and surrounding code untouched', () => {
  const src = 'function connect() {\n    const apiKey = "sk-proj-DEADBEEFDEADBEEF12345678";\n    return apiKey;\n}\n';
  const { text } = virtualizeText(src);
  assert.ok(text.startsWith('function connect() {\n    const apiKey = "'));
  assert.ok(text.includes('";\n    return apiKey;\n}\n')); // trailing code intact
  assert.ok(!text.includes('DEADBEEFDEADBEEF12345678'));
});

test('FORMAT: idempotent — re-running does not touch existing references', () => {
  const src = 'KEY=sk-proj-IDEMPOTENTKEY1234567890AB\n';
  const once = virtualizeText(src).text;
  const twice = virtualizeText(once);
  assert.equal(twice.count, 0);
  assert.equal(twice.text, once);
});

// ---------- 2. PROTECT vs TEST MODE ----------

test('MODE: PROTECT emits capability references', () => {
  const { text } = virtualizeText('OPENAI_API_KEY=sk-proj-MODEKEY1234567890ABCDEF', { mode: 'PROTECT' });
  assert.match(text, /\{\{SHADOW_SECRET_OPENAI_[A-Z0-9]{5}\}\}/);
});

test('MODE: TEST emits detector labels, still destroys the raw secret', () => {
  const { text } = virtualizeText('DATABASE_URL=mongodb+srv://test:pw123456@h.mongodb.net/db', { mode: 'TEST' });
  assert.ok(text.includes('[DETECTED_MONGODB_SECRET]'));
  assert.ok(!text.includes('pw123456'));
  assert.ok(text.startsWith('DATABASE_URL='));
});

// ---------- 3. CLASSIFICATION (no weak GENERIC) ----------

test('CLASSIFY: exact providers, ENV_SECRET replaces GENERIC', () => {
  const cases = [
    ['sk-proj-AAAABBBBCCCCDDDD11112222', 'OPENAI'],
    ['sk-ant-AAaaBBbbCCccDDdd11112222', 'ANTHROPIC'],
    ['AIzaSyAAAABBBBCCCCDDDDEEEEFFFF1234', 'GOOGLE'],
    ['ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZ012345', 'GITHUB'],
    ['glpat-ABCDEFGHIJKLMNOPQRST', 'GITLAB'],
    ['AKIAIOSFODNN7EXAMPLE', 'AWS_ACCESS_KEY'],
    ['ASIAIOSFODNN7EXAMPLE', 'AWS_SESSION'],
    ['sk_live_ABCDEFGHIJKLMNOP1234', 'STRIPE'],
    ['xoxb-1111-2222-abcdEFGH', 'SLACK'],
    ['hf_ABCDEFGHIJKLMNOPQRSTUVWX', 'HUGGINGFACE'],
    ['123456789:AAF-ABCDEFGHIJKLMNOPQRSTUVWXYZ01234', 'TELEGRAM'],
    ['mongodb+srv://u:p123456@h.mongodb.net/db', 'MONGODB'],
    ['postgres://u:p123456@h:5432/db', 'POSTGRES'],
    ['mysql://u:p123456@h:3306/db', 'MYSQL'],
    ['redis://u:p123456@h:6379', 'REDIS'],
  ];
  for (const [raw, want] of cases) {
    assert.equal(providerLabel(raw).provider, want, `${raw} → ${want}`);
  }
  // opaque high-entropy secret in a credential context is ENV_SECRET, never GENERIC
  assert.equal(providerLabel('a8Fh29Sks93jfKs02kd92xQ', 'api_key').provider, 'ENV_SECRET');
});

// ---------- 4. INLINE SECRET SCANNER ----------

test('INLINE: catches quoted/bare assignments and Bearer, value-only', () => {
  const samples = [
    'password="P@ssw0rd12345"',
    "const apiKey = 'raw-secret-value-1234'",
    'token:"abcdef1234567890xyz"',
    'client_secret=SUPERsecretVALUE0099',
    'Authorization: Bearer abcdef.ghijkl.mnopqr123456',
  ];
  for (const s of samples) {
    const { text, count } = virtualizeText(s);
    assert.ok(count >= 1, `should detect: ${s}`);
    // key/prefix must be preserved, only the value replaced
    assert.ok(text.includes('password="') || text.includes('apiKey = ') || text.includes('token:"') ||
      text.includes('client_secret=') || text.includes('Bearer '), `prefix kept: ${s}`);
  }
  const bearer = virtualizeText('Authorization: Bearer abcdef.ghijkl.mnopqr123456').text;
  assert.ok(bearer.startsWith('Authorization: Bearer '));   // header + Bearer preserved
  assert.ok(!bearer.includes('mnopqr123456'));
});

test('INLINE: does not flag placeholders/booleans/examples', () => {
  const src = 'DEBUG=true\nHOST=localhost\nAPI_KEY=your_api_key_here\nTOKEN=<YOUR_TOKEN>\nFLAG=false';
  const { count } = virtualizeText(src);
  assert.equal(count, 0);
});

// ---------- 5. EXPORT SAFETY ----------

test('EXPORT: no raw secret survives across text/json/history/clipboard shapes', () => {
  const raw1 = 'sk-proj-EXPORTLEAK1234567890ABCDEF';
  const raw2 = 'mongodb+srv://admin:leakpw123@h.mongodb.net/db';
  const src = `OPENAI_API_KEY=${raw1}\nDATABASE_URL=${raw2}\n`;
  const { text, findings } = virtualizeText(src);

  const exportsToCheck = [
    text,                                   // TXT export
    JSON.stringify({ safeText: text }),     // JSON export
    JSON.stringify(findings),               // findings / metadata
    `# History\n${text}`,                   // Markdown/history
    [text].join('\n'),                      // clipboard payload
  ];
  for (const blob of exportsToCheck) {
    assert.ok(!containsAnyRaw(blob, [raw1, raw2, 'leakpw123']), 'raw secret must not appear in export');
  }
  // findings carry provider + reference, never the raw value
  assert.ok(!JSON.stringify(findings).includes(raw1));
});

// ---------- 5b. AI COMPATIBILITY PREAMBLE ----------

test('AI: preamble instructs the model to keep references and not ask for keys', () => {
  const p = aiPreamble();
  assert.ok(/\{\{SHADOW_SECRET_/.test(p));
  assert.match(p, /NOT missing data/i);
  assert.match(p, /do not ask the user/i);
  assert.ok(!p.includes('sk-'));   // preamble itself carries no secret
});

// ---------- 6. LARGE PROJECT THROUGHPUT ----------

test('SCALE: 1000-file synthetic project virtualizes with zero leak under time budget', () => {
  const files = [];
  const raws = [];
  for (let i = 0; i < 1000; i++) {
    const raw = `sk-proj-BULK${String(i).padStart(6, '0')}ABCDEFGHIJ`;
    raws.push(raw);
    files.push(`// file_${i}.js\nconst apiKey = "${raw}";\nexport default apiKey;\n`);
  }
  const project = files.join('\n// ---- next file ----\n');
  const t0 = Date.now();
  const { text, count } = virtualizeText(project);
  const ms = Date.now() - t0;
  assert.ok(count >= 1000, `expected >=1000 detections, got ${count}`);
  assert.ok(!raws.some(r => text.includes(r)), 'no raw key may survive in a large project');
  assert.ok(ms < 4000, `1000 files should process < 4s (took ${ms}ms)`);
  // structure preserved: file markers still present
  assert.ok(text.includes('// file_0.js') && text.includes('// file_999.js'));
});
