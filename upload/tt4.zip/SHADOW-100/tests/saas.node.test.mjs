// ShadowPaste V15 SaaS-layer tests (Phases 2/4/5). Run: node --test tests
// Covers the isomorphic packages that DON'T need a DB: auth, sync, ai round-trip, rbac.
// (Backend HTTP/DB routes are separate and require Postgres — see V15_FINAL_REPORT.md.)

import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as crypto from '../packages/crypto/index.mjs';
import * as auth from '../packages/auth/index.mjs';
import * as sync from '../packages/sync/index.mjs';
import * as ai from '../packages/ai/index.mjs';
import * as rbac from '../packages/rbac/index.mjs';
import { classifyProvider } from '../packages/security/index.mjs';

test('AUTH — password hash verify + reject wrong', async () => {
  const rec = await auth.hashPassword('s3cure-pass');
  assert.equal(await auth.verifyPassword('s3cure-pass', rec), true);
  assert.equal(await auth.verifyPassword('nope', rec), false);
});

test('AUTH — access token verify / tamper / expiry', async () => {
  const ts = new auth.TokenService(await crypto.generateHmacKey());
  const a = await ts.mintAccess('u1', 'o1', 'DEVELOPER');
  assert.ok((await ts.verify(a, 'access')).ok);
  assert.equal((await ts.verify({ ...a, role: 'OWNER' }, 'access')).ok, false);
  const exp = await ts.mintAccess('u', 'o', 'VIEWER', -1);
  assert.equal((await ts.verify(exp, 'access')).ok, false);
});

test('AUTH — refresh rotation revokes the old token', async () => {
  const ts = new auth.TokenService(await crypto.generateHmacKey());
  const r = await ts.mintRefresh('u1');
  const rot = await ts.rotateRefresh(r, 'o1', 'DEVELOPER');
  assert.ok(rot.ok);
  assert.equal((await ts.verify(r, 'refresh')).ok, false);
});

test('AUTH — brute-force lockout', () => {
  const th = new auth.LoginThrottle({ max: 3 });
  th.fail('ip'); th.fail('ip'); const r = th.fail('ip');
  assert.ok(r.locked);
  assert.equal(th.check('ip').allowed, false);
});

test('SYNC — server bundle never contains plaintext; round-trips; wrong pass fails', async () => {
  const sm = new sync.SyncManager('pass-A');
  const bundle = await sm.pack([{ reference: '{{SHADOW_SECRET_OPENAI_X}}', provider: 'OPENAI', plaintext: 'sk-live-REAL-123' }]);
  assert.equal(sync.bundleLeaks(bundle, 'sk-live-REAL-123'), false);
  const back = await sm.unpack(bundle);
  assert.equal(back[0].plaintext, 'sk-live-REAL-123');
  await assert.rejects(new sync.SyncManager('pass-B').unpack(bundle));
});

test('SYNC — merge resolves conflicts by version then updatedAt', async () => {
  const sm = new sync.SyncManager('p');
  const b1 = await sm.pack([{ reference: 'r1', provider: 'X', plaintext: 'a' }], { version: 1 });
  const b2 = await sm.pack([{ reference: 'r1', provider: 'X', plaintext: 'b' }], { version: 2 });
  assert.equal(sm.merge(b1, b2).version, 2);
});

test('AI — {{SHADOW_SECRET_*}} survives round trip through a fake provider', async () => {
  // in-memory protect/restore backed by a map (mirrors the vault contract)
  const map = new Map(); let n = 0;
  const protect = async (text) => {
    for (const m of [...text.matchAll(/(sk-[A-Za-z0-9]{10,}|mongodb\+srv:\/\/[^\s"]+)/g)]) {
      const prov = classifyProvider(m[1]).provider; const ref = `{{SHADOW_SECRET_${prov}_${n++}}}`;
      map.set(ref, m[1]); text = text.split(m[1]).join(ref);
    }
    return { text };
  };
  const restore = async (text) => { for (const [ref, raw] of map) text = text.split(ref).join(raw); return { text }; };
  const rt = await ai.roundTrip({
    project: 'KEY="sk-test1234567890"\nDB="mongodb+srv://a:b@x.net/db"',
    provider: ai.fakeProvider(), protect, restore
  });
  assert.equal(rt.referencesSurvived, true);
  assert.ok(rt.restored.includes('sk-test1234567890'));
  assert.ok(rt.restored.includes('mongodb+srv://a:b@x.net/db'));
  assert.ok(!rt.safeSent.includes('sk-test1234567890'));
});

test('RBAC — developer cannot revoke or approve; viewer read-only', () => {
  assert.equal(rbac.can('DEVELOPER', 'secret.use'), true);
  assert.equal(rbac.can('DEVELOPER', 'secret.revoke'), false);
  assert.equal(rbac.can('DEVELOPER', 'ai.approve_high_risk'), false);
  assert.equal(rbac.permissionsFor('VIEWER').length, 0);
});
