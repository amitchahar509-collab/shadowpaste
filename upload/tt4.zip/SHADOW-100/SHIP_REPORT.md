# ShadowPaste V11.1 RC — SHIP REPORT

Environment used for validation (Phase 1):
- **Node: NOT INSTALLED** · **npm: NOT INSTALLED** · **Docker: NOT INSTALLED** · Python 3.13.7 (static server)
- Browser JS engine (Chromium preview) — shares WebCrypto/`fetch` with Node ≥20.
- Network: available (fetched CDN libs to compute SRI hashes).

Consequence: everything runnable in a JS engine was executed and verified. Node/Docker paths are
**code-complete but not executed here** — labeled below. Nothing is claimed without execution.

## [VERIFIED RUNNING] (executed in-browser this pass)
- Web app boots, vault armed (AES-GCM), no console errors.
- E2E: paste `OPENAI_API_KEY=sk-…` → `{{SHADOW_SECRET_OPENAI_…}}`, raw absent from output. ✅
- Runtime execution via `ShadowPasteRuntime.useSecret` → ok, no raw key in result. ✅
- Red team: prompt-injection flagged, `requestSecretReveal` DENIED, expired token rejected,
  CRITICAL action rejected, **XSS payload escaped** (no element injected). ✅
- Packages (crypto/capability/security/gateway/runtime) end-to-end vs mock provider. ✅
- Passphrase-locked vault: correct key decrypts, wrong key throws. ✅
- **5 CDN libraries load under real SRI SHA-384 pins** (XLSX/pdf.js/Tesseract/JSZip/mammoth). ✅
- Perf: 1000-secret `.env` fully virtualized, no leak. ✅

## [FIXED] this pass
- **Perf / UI freeze:** 1000-secret paste **9.1s → 2.2s** by batching the bulk path into single
  IndexedDB transactions + preloaded dedup cache (manual-add path unchanged). In-batch dedup verified.
- **Supply chain:** added real SRI SHA-384 integrity to all 5 CDN scripts (verified they still load).
- **Service worker:** network-first for HTML (was cache-first → stale shell) so updates appear on reload.

## [CODE EXISTS BUT NOT EXECUTED] (needs Node/Docker — run locally)
- `server/server.mjs` (Fastify, 6 routes incl. `/policy/check`) — `cd server && npm i && npm start`.
- `tests/runtime.node.test.mjs` + `tests/redteam.node.test.mjs` — `node --test tests`. Logic is identical
  to the browser-verified path, so results are *expected* to match; not asserted as executed.
- `Dockerfile` build; `.github/workflows/ci.yml`.
- **Live provider call** (real OpenAI/Anthropic/Gemini) — see `LIVE_PROVIDER_TEST.md`; needs your key + network.

## [FAILED]
- None outstanding. (The stale-cache and 9s-freeze findings above were fixed and re-verified.)
