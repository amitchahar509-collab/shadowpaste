// ShadowPaste V8 Runtime Server (Phase 2) — Fastify.
// Endpoints: /runtime/execute, /capability/create, /capability/verify,
//            /audit/event, /vault/request, /health
// Guarantees: never logs secrets, never returns raw secrets, memory-only keys.
//
// Run:  cd server && npm install && npm start   (Node >=20)
// Env:  see ../.env.example

import Fastify from 'fastify';
import rateLimit from '@fastify/rate-limit';
import helmet from '@fastify/helmet';
import cors from '@fastify/cors';

import { generateAesKey, generateHmacKey, importHmacKey } from '../packages/crypto/index.mjs';
import { CapabilityEngine, newSessionId } from '../packages/capability/index.mjs';
import { Gateway, VaultStore } from '../packages/gateway/index.mjs';
import { FirewallV2, classifyProvider } from '../packages/security/index.mjs';

const PORT = process.env.PORT || 8787;
const HMAC_SECRET = process.env.SHADOWPASTE_HMAC_SECRET; // required in prod

// ---- process-lifetime key material (never persisted, never logged) ----
const aesKey = await generateAesKey(false);
const hmacKey = HMAC_SECRET ? await importHmacKey(HMAC_SECRET) : await generateHmacKey(false);
const capabilities = new CapabilityEngine(hmacKey);
const vault = new VaultStore(aesKey);
const auditTrail = [];
const audit = (evt) => { auditTrail.push(evt); if (auditTrail.length > 1000) auditTrail.shift(); };

const app = Fastify({
  logger: { level: process.env.LOG_LEVEL || 'info',
    // redact any header/field that could carry a credential
    redact: ['req.headers.authorization', 'req.headers["x-api-key"]', '*.apiKey', '*.secret', '*.encryptedSecret'] },
  bodyLimit: 256 * 1024
});

await app.register(helmet, { contentSecurityPolicy: { directives: {
  defaultSrc: ["'self'"], scriptSrc: ["'self'"], objectSrc: ["'none'"], baseUri: ["'none'"], frameAncestors: ["'none'"]
} } });
await app.register(cors, { origin: (process.env.CORS_ORIGINS || '').split(',').filter(Boolean) || false, methods: ['POST', 'GET'] });
await app.register(rateLimit, { max: Number(process.env.RATE_MAX || 60), timeWindow: '1 minute' });

const sessions = new Map(); // sessionId -> gateway

function gatewayFor(sessionId) {
  if (!sessions.has(sessionId)) {
    sessions.set(sessionId, new Gateway({
      vault, capabilities, sessionId, audit,
      fetchImpl: fetch,
      approveHighRisk: async () => false // server default: HIGH needs explicit out-of-band approval
    }));
  }
  return sessions.get(sessionId);
}
function requireFields(body, fields, reply) {
  for (const f of fields) if (body?.[f] == null) { reply.code(400).send({ ok: false, error: `missing field: ${f}` }); return false; }
  return true;
}

app.get('/health', async () => ({ ok: true, service: 'shadowpaste-runtime', version: '8.0.0' }));

// Store a secret in the encrypted vault; returns only the capability reference.
app.post('/vault/request', async (req, reply) => {
  const b = req.body || {};
  if (!requireFields(b, ['secret'], reply)) return;
  const cls = classifyProvider(b.secret, b.context || '');
  const rec = await vault.add(b.secret, { provider: cls.provider, scope: cls.scope, ttlMs: b.ttlMs });
  return { ok: true, reference: rec.reference, provider: rec.provider, scope: rec.scope, blastRadius: rec.blastRadius };
});

// Mint a capability token for a reference + action (session-bound).
app.post('/capability/create', async (req, reply) => {
  const b = req.body || {};
  if (!requireFields(b, ['reference', 'action', 'sessionId'], reply)) return;
  const rec = vault.get(b.reference);
  if (!rec) return reply.code(404).send({ ok: false, error: 'unknown reference' });
  const token = await capabilities.mint({ secretId: rec.id, sessionId: b.sessionId, scope: rec.scope, action: b.action });
  return { ok: true, token };
});

app.post('/capability/verify', async (req, reply) => {
  const b = req.body || {};
  if (!requireFields(b, ['token'], reply)) return;
  return { ok: true, result: await capabilities.verify(b.token, { sessionId: b.sessionId, requiredScope: b.requiredScope }) };
});

// The runtime executor: validate → decrypt-in-scope → provider call → result only.
app.post('/runtime/execute', async (req, reply) => {
  const b = req.body || {};
  if (!requireFields(b, ['reference', 'action', 'sessionId'], reply)) return;
  const promptRisk = FirewallV2.assessPrompt(b.payload?.prompt || '', { session: b.sessionId });
  if (promptRisk.level === 'CRITICAL') return reply.code(403).send({ ok: false, error: 'DENIED by firewall', risk: promptRisk });
  const result = await gatewayFor(b.sessionId).requestSecretUse(b.reference, b.action, b.payload || {});
  return reply.code(result.ok ? 200 : 403).send(result);
});

// Policy pre-flight: score a prompt + action WITHOUT touching a secret.
app.post('/policy/check', async (req, reply) => {
  const b = req.body || {};
  const promptRisk = FirewallV2.assessPrompt(b.prompt || '', { session: b.sessionId });
  const actionRisk = b.action ? FirewallV2.assessAction(b.action) : { level: 'LOW', reason: 'no action' };
  const decision = (promptRisk.level === 'CRITICAL' || actionRisk.level === 'CRITICAL') ? 'DENY'
    : (promptRisk.level === 'HIGH' || actionRisk.level === 'HIGH') ? 'REQUIRE_APPROVAL' : 'ALLOW';
  return { ok: true, decision, promptRisk, actionRisk };
});

app.post('/audit/event', async (req) => { audit({ ...(req.body || {}), ts: Date.now(), external: true }); return { ok: true }; });
app.get('/audit/event', async () => ({ ok: true, count: auditTrail.length, events: auditTrail.slice(-100) }));

app.listen({ port: PORT, host: '0.0.0.0' })
  .then(() => app.log.info(`ShadowPaste runtime on :${PORT} (session=${newSessionId().slice(0, 12)}…)`))
  .catch((e) => { app.log.error(e); process.exit(1); });
