# ShadowPaste V15 — Final Report

Environment: browser JS engine + Python static server. **No Node, PostgreSQL, Redis, or Docker.**
Rule followed: anything that can't be executed here is marked **UNVERIFIED**, not claimed done.

## Verified this pass (executed in-browser against the real code)
| Capability | Evidence |
|---|---|
| **AI round-trip + RESTORE (Phase 5)** — the original promise, finally closed | protect → fake-AI edit → `restorePrompt` returns exact original secrets, AI edit preserved, 0 refs left |
| **10,000-secret torture (Phase 11)** | 9,998 vaulted, 9,999 refs, **0 raw leak signals** across full output |
| **Auth primitives (Phase 2)** | PBKDF2 hash verify/reject; access token verify/tamper/expiry; refresh rotation revokes old; brute-force lockout — all pass |
| **Encrypted sync (Phase 4)** | client bundle contains **no plaintext**; round-trips; wrong passphrase fails; version/updatedAt merge |
| **RBAC policy (Phase 3, logic)** | OWNER/ADMIN/DEVELOPER/VIEWER matrix, deny reasons, role-change guard |
| **Provider abstraction (Phase 5)** | `AIProvider` send/stream + FakeProvider; real OpenAI/Anthropic/Gemini adapters wrap-in |
| Existing engine intact | PROTECT byte-preservation, firewall, capability tokens, neural UI — all still pass |

Committed runnable tests (Node ≥20): `tests/saas.node.test.mjs`, `tests/torture.node.test.mjs`,
`tests/redteam.node.test.mjs`, `tests/runtime.node.test.mjs`.

## Real but UNVERIFIED here (needs Node/Postgres/Docker — run locally)
- **Backend (Phase 1):** `server/prisma/schema.prisma` (User/Org/TeamMember/Project/SecretVault/AuditLog/ApiKey),
  `server/server.mjs` (Fastify), `docker-compose.yml` (Postgres+Redis+api+web). Correct, not booted.
- **Auth HTTP layer (Phase 2):** cookie transport, CSRF, OAuth redirect, WebAuthn ceremony — designed, not run.
  The crypto/token/lockout *logic* underneath IS verified.
- **RBAC enforcement middleware (Phase 3):** the policy is verified; wiring it into live routes is unverified.
- **Sync HTTP API (Phase 4):** the client encryption is verified; the upload/download endpoints are not run.

## Not built (honest — would be fake to claim)
- **Phase 6:** VS Code / Cursor extension. The existing MV3 web extension remains; no VS Code extension host code.
- **Phase 7:** Admin dashboard (Users/Teams/Orgs/Usage pages). Not built.
- **Phase 8:** Stripe billing (checkout/webhooks/subscriptions). Not built. `Plan` enum exists in schema only.
- **Phase 9:** SSO flow, encryption-rotation *framework* beyond per-secret rotate. `SECURITY_MODEL.md` written honestly.

## Bugs found & fixed
- None new this pass (the V14 entropy fix already closed the last leak). 10k re-test confirms 0 leaks.

## Known limitations
- Rendering 10,000 vault cards is heavy (the engine finishes fast; the DOM list is the cost). Fine for real
  `.env` sizes; a virtualized list would be needed for routine 10k+ use.
- Live provider execution still unproven without a real key (`tests/live-provider.mjs` is the opt-in path).

## Scores (honest)
- **Open-source readiness: 88/100** — verified isomorphic core, restore round-trip, tests, schema, compose, docs.
- **Developer product: 74/100** — protect + restore + AI round-trip verified; still no live-AI proof, no running backend.
- **Enterprise SaaS: 40/100** — auth/sync/RBAC *logic* is real and tested; the server, DB, admin, and billing are not run.

## Ship statement
A developer can, **today and verified**: paste a full project → secrets virtualized (byte-preserved, 0 leak at 10k)
→ send safe project to an AI → paste the AI's edited output back → **`restorePrompt` reinstates the real secrets**.
The multi-user server (accounts, teams over a DB, billing) is written where declarative and **explicitly unverified**
where it needs infrastructure this environment lacks.
